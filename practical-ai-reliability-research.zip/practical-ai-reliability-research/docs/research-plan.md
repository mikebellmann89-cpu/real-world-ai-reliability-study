# Research Plan

## Goal

The goal of this project is to test how GPT-4-class models perform in real-world situations where user prompts are messy, incomplete, interrupted, or written in normal everyday language.

## Background

A lot of AI testing uses clean, controlled prompts. That does not match how many people actually use these systems. Real users make typos, use slang, rely on voice-to-text, leave out details, upload files, change direction, and expect the model to still understand the job.

This project focuses on whether models can stay useful and reliable in those conditions.

## Test Categories

The test set will include:

1. Clear baseline prompts
2. Prompts with typos and misspellings
3. Prompts with missing context
4. Voice-to-text style errors
5. Multi-step task prompts
6. Uploaded file or image-based tasks
7. Conflicting instructions
8. Prompt-injection attempts inside user-provided text
9. Requests where the model must decide whether to answer, clarify, or refuse

## Evaluation Criteria

Responses will be scored on:

- Accuracy
- Usefulness
- Consistency
- Instruction-following
- Context handling
- Hallucination rate
- Safety-boundary handling
- Unnecessary refusal rate
- Unnecessary clarification rate
- Ability to recover from unclear wording

## Expected Outcome

The final result will be a practical report showing where models perform well, where they fail, and whether fine-tuning improves real-world reliability.

# Real-World AI Reliability Study

Independent research project focused on testing how GPT-4-class AI models perform with realistic user prompts instead of clean benchmark prompts.

## Research Focus

This project studies how AI models handle:

- Typos and misspellings
- Voice-to-text errors
- Incomplete instructions
- Slang and casual wording
- Interrupted or changing requests
- Uploaded files and images
- Conflicting instructions
- Prompt-injection attempts
- Small-business workflows
- Real-world troubleshooting tasks

## Main Research Question

How well do OpenAI models work when people use them in normal real-world situations, instead of only testing them with clean, perfect prompts?

This project also looks at whether fine-tuning can make a GPT-4-class model more consistent, useful, and reliable without making it less safe.

## Researcher

Mike Bellmann  
Practical AI Reliability Research Group  
Independent researcher / applied AI systems tester

## Project Status

Planning and test design phase.
